#!/usr/bin/env bash
# Bootstrap a 3-node Elasticsearch 8.18.4 cluster on RHEL 8.9 using enrollment tokens.
set -euo pipefail

CLUSTER_NAME="${CLUSTER_NAME:-es-cluster}"
NODE01_HOST="${NODE01_HOST:-ISMELKESNODE01}"
NODE02_HOST="${NODE02_HOST:-ISMELKESNODE02}"
NODE03_HOST="${NODE03_HOST:-ISMELKESNODE03}"

NODE01_IP="${NODE01_IP:-10.44.40.31}"
NODE02_IP="${NODE02_IP:-10.44.40.32}"
NODE03_IP="${NODE03_IP:-10.44.40.33}"

ES_BIN="/usr/share/elasticsearch/bin"
CURRENT_HOST=$(hostname -s)

wait_for_es() {
  local host=$1
  local max=60
  local i=0
  echo "Waiting for Elasticsearch on ${host}..."
  while (( i < max )); do
    if curl -sk --connect-timeout 2 "https://${host}:9200" &>/dev/null; then
      echo "  ${host} is up."
      return 0
    fi
    sleep 5
    ((i++))
  done
  echo "Timed out waiting for ${host}" >&2
  return 1
}

configure_first_node() {
  local yml="/etc/elasticsearch/elasticsearch.yml"

  # First node: bind transport, set seed hosts for 3-node cluster
  grep -q '^cluster.initial_master_nodes:' "$yml" || cat >> "$yml" <<EOF

cluster.initial_master_nodes:
  - ${NODE01_HOST}
  - ${NODE02_HOST}
  - ${NODE03_HOST}
discovery.seed_hosts:
  - ${NODE01_IP}:9300
  - ${NODE02_IP}:9300
  - ${NODE03_IP}:9300
EOF

  systemctl start elasticsearch
  wait_for_es "localhost"

  echo ""
  echo "=== Reset elastic superuser password (save this) ==="
  "$ES_BIN/elasticsearch-reset-password" -u elastic -i

  echo ""
  echo "=== Kibana enrollment token (valid 30 min) ==="
  "$ES_BIN/elasticsearch-create-enrollment-token" -s kibana
}

enroll_additional_node() {
  local token="${NODE_ENROLLMENT_TOKEN:-}"

  if [[ -z "$token" ]]; then
    echo "NODE_ENROLLMENT_TOKEN not set."
    echo "On es-node01, run:"
    echo "  $ES_BIN/elasticsearch-create-enrollment-token -s node"
    echo "Then on this node:"
    echo "  NODE_ENROLLMENT_TOKEN='<token>' bash $0"
    exit 1
  fi

  echo "Reconfiguring ${CURRENT_HOST} with enrollment token..."
  "$ES_BIN/elasticsearch-reconfigure-node" --enrollment-token "$token" <<< 'y'

  # Ensure cluster name matches
  sed -i "s/^cluster.name:.*/cluster.name: ${CLUSTER_NAME}/" /etc/elasticsearch/elasticsearch.yml

  systemctl start elasticsearch
  wait_for_es "localhost"
}

case "$CURRENT_HOST" in
  "$NODE01_HOST")
    echo "=== Bootstrapping first node: ${NODE01_HOST} ==="
    configure_first_node
    ;;
  "$NODE02_HOST"|"$NODE03_HOST")
    echo "=== Enrolling node: ${CURRENT_HOST} ==="
    enroll_additional_node
    ;;
  *)
    echo "Unknown host '${CURRENT_HOST}'. Set hostname to one of: ${NODE01_HOST}, ${NODE02_HOST}, ${NODE03_HOST}" >&2
    exit 1
    ;;
esac

echo ""
echo "=== Cluster health (from ${CURRENT_HOST}) ==="
# Password must be set in ELASTIC_PASSWORD env var for this check
if [[ -n "${ELASTIC_PASSWORD:-}" ]]; then
  curl -sk --cacert /etc/elasticsearch/certs/http_ca.crt \
    -u "elastic:${ELASTIC_PASSWORD}" \
    "https://localhost:9200/_cluster/health?pretty"
else
  echo "Set ELASTIC_PASSWORD and run:"
  echo "  curl -sk --cacert /etc/elasticsearch/certs/http_ca.crt -u elastic:\$ELASTIC_PASSWORD https://localhost:9200/_cluster/health?pretty"
fi